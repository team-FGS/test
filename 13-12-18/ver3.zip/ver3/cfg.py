#DB_URI='mysql+pymysql://root:johny21@127.0.0.1:3306/promotion?charset=utf8&use_unicode=1'
#DB_URI='mysql+pymysql://root:@cat20@119.59.121.79:3306/facial_recognition?charset=utf8&use_unicode=1'
#DB_URI='mysql+pymysql://root:Seefararah112@127.0.0.1:3306/db?charset=utf8mb4'
DB_URI='sqlite:///socglo.db'

DEBUG=True

PORT=8070

